from django.apps import AppConfig


class DajaxConfig(AppConfig):
    name = 'dajax'
    verbose_name = "Django URL resolver for Ajax"
